/* Javascript for onze.cool */
